../build/src/image_test \
