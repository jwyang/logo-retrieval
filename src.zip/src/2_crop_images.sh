../build/src/crop_images \
